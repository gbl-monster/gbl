import cv2
import numpy as np

def cnt_area(cnt):
    area = cv2.contourArea(cnt)
    return area


image = cv2.imread('car1.jpeg')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

gray = cv2.bilateralFilter(gray, 0, 17, 17)
edged = cv2.Canny(gray, 170, 200)

cnts,new = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
cnts = sorted(cnts,key=cv2.contourArea,reverse=True)[:30]

NumberPlateCnt = None
for c in cnts:
    peri = cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, 0.02 * peri, True)
    if len(approx) == 4:
        NumberPlateCnt = approx
        break

print(NumberPlateCnt)
cv2.drawContours(image, [NumberPlateCnt], -1, (0, 255, 0), 3)
cv2.imshow("result", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
